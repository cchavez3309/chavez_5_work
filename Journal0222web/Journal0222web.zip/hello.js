alert('Howdy!')
window.alert('this is a window')
window.confirm('shall we continue!')
var r = confirm("press a button")
